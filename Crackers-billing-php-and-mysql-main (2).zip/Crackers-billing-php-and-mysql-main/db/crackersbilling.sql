-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2025 at 01:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crackersbilling`
--

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `invoice_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_address` text NOT NULL,
  `invoice_date` date NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `gst` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `discount_percentage` decimal(5,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`invoice_id`, `customer_name`, `customer_address`, `invoice_date`, `subtotal`, `gst`, `total_amount`, `discount_percentage`) VALUES
(1, 'vetrivelan', 'avaniyapuram', '2024-09-26', 1200.00, 60.00, 1260.00, 0.00),
(2, 'veeramani', 'vilacheri, madurai', '2024-09-13', 1200.00, 60.00, 1260.00, 0.00),
(3, 'Chellapandian', 'Madurai', '2024-09-27', 6000.00, 300.00, 6300.00, 0.00),
(4, 'Dinesh Kumar', 'Pudur,madurai', '2024-09-27', 10000.00, 500.00, 10500.00, 0.00),
(5, 'Dinesh Pandi', 'Mannagiri,madurai', '2024-09-27', 2250.00, 112.50, 2362.50, 0.00),
(6, 'kamesh karthi', 'madurai', '2024-09-27', 1050.00, 52.50, 1102.50, 0.00),
(7, 'kamesh karthi', 'madurai', '2024-09-27', 1050.00, 52.50, 1102.50, 0.00),
(8, 'kamesh karthi', 'madurai', '2024-09-27', 1050.00, 52.50, 1102.50, 0.00),
(9, 'Muthu Kumar', 'pudhur, Madurai', '2024-09-27', 2500.00, 125.00, 2625.00, 0.00),
(10, 'Ganesh', 'Madurai', '2024-09-28', 8000.00, 400.00, 8400.00, 0.00),
(11, 'raghupathy', 'kariyapatti', '2024-09-28', 21500.00, 1075.00, 22575.00, 0.00),
(12, 'raghupathy', 'kariyapatti', '2024-09-28', 21500.00, 1075.00, 22575.00, 0.00),
(13, 'mugundhan', 'cochin,kerala', '2024-09-28', 7200.00, 360.00, 7560.00, 0.00),
(14, 'Rajavel', 'dindigul', '2024-09-28', 400.00, 20.00, 420.00, 0.00),
(15, 'karthik', 'sivakasi', '2024-09-28', 500.00, 25.00, 525.00, 0.00),
(16, 'raviteja', 'andhra', '2024-09-28', 60.00, 3.00, 63.00, 0.00),
(17, 'ilayaraja', 'chennai', '2024-09-30', 500.00, 25.00, 525.00, 0.00),
(18, 'senthil', 'karur', '2024-09-30', 201.00, 10.05, 211.05, 0.00),
(19, 'Pradeep', 'madurai', '2024-09-30', 1750.00, 87.50, 1837.50, 0.00),
(20, 'sadha', 'sithur', '2024-09-30', 500.00, 25.00, 525.00, 0.00),
(21, 'rajavel', 'karaikudi', '2024-09-30', 1300.00, 65.00, 1365.00, 0.00),
(22, 'veera', 'theni', '2024-09-30', 1000.00, 47.50, 997.50, 0.00),
(23, 'Aathirai', 'madurai', '2024-09-30', 300.00, 14.25, 299.25, 5.00),
(24, 'Nirmal', 'karaikudi', '2024-09-30', 600.00, 28.50, 598.50, 5.00),
(25, 'Guru', 'dubai', '2024-09-29', 202.00, 9.09, 190.89, 10.00),
(26, 'budha', 'china', '2024-09-30', 1500.00, 67.50, 1417.00, 10.00),
(27, 'kavin ', 'coimbatore', '2024-09-30', 250.00, 5.00, 240.00, 6.00),
(28, 'naveen', 'Natham, dindugal', '2024-10-01', 3250.00, 146.25, 3071.25, 10.00),
(29, 'naveenkumar', 'madurai', '2024-10-01', 25625.00, 1281.25, 26906.25, 0.00),
(30, 'Gandhi', 'Gujarat', '2024-10-01', 3900.00, 195.00, 4095.00, 0.00),
(31, 'Bheema', 'Thirunagar, tel- 8778787810', '2024-10-02', 6360.00, 308.46, 6477.66, 3.00),
(32, 'Billa', 'cochin, Kerala', '2024-10-03', 6961.00, 337.61, 7089.78, 3.00),
(33, 'dheeran', 'dindugal', '2024-10-03', 322.00, 16.10, 338.10, 0.00),
(34, 'Jai Ganesh', 'kalavasal,madurai', '2024-10-04', 2433.00, 109.49, 2299.19, 10.00),
(35, 'jeeva', 'chennai', '2024-10-05', 860.00, 43.00, 903.00, 0.00),
(36, 'gnanavel', 'chennai', '2024-10-05', 860.00, 43.00, 903.00, 0.00),
(37, 'raja', 'madurai', '2025-05-02', 600.00, 30.00, 630.00, 0.00),
(38, 'raja', 'madurai', '2025-05-02', 100.00, 5.00, 105.00, 0.00),
(39, 'raja', 'madurai', '2025-05-02', 300.00, 14.85, 311.85, 1.00);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_items`
--

CREATE TABLE `invoice_items` (
  `item_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_size` varchar(10) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoice_items`
--

INSERT INTO `invoice_items` (`item_id`, `invoice_id`, `product_name`, `product_size`, `quantity`, `price`, `total`, `product_id`) VALUES
(1, 1, 'mini bomb', 'M', 2, 100.00, 200.00, 0),
(2, 1, 'hydro bomb', 'S', 2, 200.00, 400.00, 0),
(3, 1, 'bomb', 'L', 2, 300.00, 600.00, 0),
(4, 2, 'mini bomb', 'M', 2, 100.00, 200.00, 0),
(5, 2, 'hydro bomb', 'S', 2, 200.00, 400.00, 0),
(6, 2, 'bomb', 'L', 2, 300.00, 600.00, 0),
(7, 3, 'flower pot', 'M', 10, 100.00, 1000.00, 0),
(8, 3, 'ground chakra', 'S', 10, 100.00, 1000.00, 0),
(9, 3, 'Out', 'L', 5, 200.00, 1000.00, 0),
(10, 3, 'Bullet Bomb', 'L', 10, 300.00, 3000.00, 0),
(11, 4, '1000 wala', 'M', 10, 1000.00, 10000.00, 0),
(12, 5, 'bijili', 'L', 5, 150.00, 750.00, 0),
(13, 5, 'sky crackers', 'S', 5, 300.00, 1500.00, 0),
(14, 6, 'flower pot', 'M', 3, 150.00, 450.00, 0),
(15, 6, 'bomb', 'M', 3, 200.00, 600.00, 0),
(16, 7, 'flower pot', 'M', 3, 150.00, 450.00, 0),
(17, 7, 'bomb', 'M', 3, 200.00, 600.00, 0),
(18, 8, 'flower pot', 'M', 3, 150.00, 450.00, 0),
(19, 8, 'bomb', 'M', 3, 200.00, 600.00, 0),
(20, 9, 'Hydrogen bomb', 'L', 5, 250.00, 1250.00, 0),
(21, 9, 'bullet bomb', 'L', 5, 250.00, 1250.00, 0),
(22, 10, 'Bullet Bomb', 'M', 20, 250.00, 5000.00, 0),
(23, 10, 'Out', 'M', 10, 300.00, 3000.00, 0),
(24, 12, '', 'L', 20, 1000.00, 20000.00, 3),
(25, 12, '', 'M', 25, 60.00, 1500.00, 12),
(26, 13, '', 'M', 3, 2000.00, 6000.00, 6),
(27, 13, '', 'L', 12, 100.00, 1200.00, 2),
(28, 15, 'Gun', 'M', 10, 50.00, 500.00, 14),
(29, 16, 'roll cap', 'M', 1, 60.00, 60.00, 15),
(30, 17, 'Bijili pockets', 'L', 5, 100.00, 500.00, 17),
(31, 18, 'Flower Pot', 'S', 1, 100.00, 100.00, 2),
(32, 18, 'Big Pots', 'M', 1, 101.00, 101.00, 1),
(33, 19, 'peocock feather', 'L', 5, 300.00, 1500.00, 18),
(34, 19, 'Gun', 'M', 5, 50.00, 250.00, 14),
(35, 20, 'Flower Pot', 'S', 5, 100.00, 500.00, 2),
(36, 21, 'special crackers', 'L', 2, 600.00, 1200.00, 7),
(37, 21, 'Flower Pot', 'S', 1, 100.00, 100.00, 2),
(38, 22, 'color full', 'M', 10, 100.00, 1000.00, 13),
(39, 23, 'Twinkle star', 'S', 5, 60.00, 300.00, 12),
(40, 24, 'peocock feather', 'L', 2, 300.00, 600.00, 18),
(41, 25, 'Big Pots', 'M', 2, 101.00, 202.00, 1),
(42, 26, 'spinner', 'M', 10, 150.00, 1500.00, 11),
(43, 27, 'Gun', 'M', 5, 50.00, 250.00, 14),
(44, 28, 'Golden rain', 'M', 2, 1300.00, 2600.00, 20),
(45, 28, 'spring cracker', 'L', 3, 50.00, 150.00, 10),
(46, 28, 'color full', 'M', 5, 100.00, 500.00, 13),
(47, 29, 'Golden rain', 'M', 5, 1300.00, 6500.00, 20),
(48, 29, 'spring cracker', 'L', 5, 50.00, 250.00, 10),
(49, 29, 'Ariel Out pipes', 'L', 5, 2000.00, 10000.00, 6),
(50, 29, 'seven shot', 'L', 5, 1000.00, 5000.00, 3),
(51, 29, 'Flower Pot', 'S', 5, 100.00, 500.00, 2),
(52, 29, 'spring cracker', 'L', 5, 50.00, 250.00, 10),
(53, 29, 'plains shot', 'M', 5, 225.00, 1125.00, 16),
(54, 29, 'Bijili pockets', 'L', 5, 100.00, 500.00, 17),
(55, 29, 'peocock feather', 'L', 5, 300.00, 1500.00, 18),
(56, 30, 'seven-shot', 'L', 3, 300.00, 900.00, 21),
(57, 30, 'seven shot', 'M', 3, 1000.00, 3000.00, 3),
(58, 31, '1000-gems', 'L', 2, 1200.00, 2400.00, 22),
(59, 31, 'six shot', 'M', 2, 800.00, 1600.00, 4),
(60, 31, 'mercury', 'M', 2, 180.00, 360.00, 19),
(61, 31, 'seven shot', 'M', 2, 1000.00, 2000.00, 3),
(62, 32, '1kg single piece', 'L', 1, 500.00, 500.00, 8),
(63, 32, 'Eight shot cracker', 'M', 1, 150.00, 150.00, 23),
(64, 32, 'color full', 'M', 1, 100.00, 100.00, 13),
(65, 32, 'Big Pots', 'M', 1, 101.00, 101.00, 1),
(66, 32, 'Flower Pot', 'S', 1, 100.00, 100.00, 2),
(67, 32, 'seven shot', 'M', 1, 1000.00, 1000.00, 3),
(68, 32, 'six shot', 'M', 1, 800.00, 800.00, 4),
(69, 32, 'five shots', 'L', 1, 1000.00, 1000.00, 5),
(70, 32, 'Ariel Out pipes', 'L', 1, 2000.00, 2000.00, 6),
(71, 32, 'special crackers', 'L', 1, 600.00, 600.00, 7),
(72, 32, 'spinner', 'M', 1, 150.00, 150.00, 11),
(73, 32, 'Bijili pockets', 'L', 1, 100.00, 100.00, 17),
(74, 32, 'peocock feather', 'L', 1, 300.00, 300.00, 18),
(75, 32, 'Twinkle star', 'S', 1, 60.00, 60.00, 12),
(76, 33, 'Big Pots', 'M', 2, 101.00, 202.00, 1),
(77, 33, 'Twinkle star', 'S', 2, 60.00, 120.00, 12),
(78, 34, 'Big Pots', 'M', 3, 101.00, 303.00, 1),
(79, 34, 'Flower Pot', 'S', 3, 100.00, 300.00, 2),
(80, 34, 'Twinkle star', 'S', 3, 60.00, 180.00, 12),
(81, 34, 'spring cracker', 'L', 3, 50.00, 150.00, 10),
(82, 34, '1kg single piece', 'L', 3, 500.00, 1500.00, 8),
(83, 35, 'star cracker', 'L', 2, 230.00, 460.00, 24),
(84, 35, 'Asfarifa', 'L', 2, 200.00, 400.00, 9),
(85, 36, 'star cracker', 'L', 2, 230.00, 460.00, 24),
(86, 36, 'Asfarifa', 'L', 2, 200.00, 400.00, 9),
(87, 37, 'roll cap', 'M', 10, 60.00, 600.00, 15),
(88, 38, 'color full', 'M', 1, 100.00, 100.00, 13),
(89, 39, 'spinner', 'M', 2, 150.00, 300.00, 11);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `profile_image`) VALUES
(1, 'admin', 'admin', 'adminimg.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `size` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `image`, `size`, `quantity`, `amount`, `created_at`) VALUES
(1, 'Big Pots', '4.jpg', 'M', 20, 101.00, '2024-09-25 18:21:27'),
(2, 'Flower Pot', '4.jpg', 'S', 4, 100.00, '2024-09-25 18:21:27'),
(3, 'seven shot', 'Seven-Shots-1.png', 'M', 50, 1000.00, '2024-09-25 18:21:27'),
(4, 'six shot', '2.jpg', 'M', 50, 800.00, '2024-09-25 18:21:27'),
(5, 'five shots', 'Seven-Shots-1.png', 'L', 50, 1000.00, '2024-09-25 18:21:27'),
(6, 'Ariel Out pipes', '5.jpg', 'L', 5, 2000.00, '2024-09-25 18:21:27'),
(7, 'special crackers', '12.jpg', 'L', 40, 600.00, '2024-09-25 18:59:05'),
(8, '1kg single piece', '1kg.jpg', 'L', 10, 500.00, '2024-09-27 10:45:34'),
(9, 'Asfarifa', '1.jpg', 'L', 10, 200.00, '2024-09-27 19:20:03'),
(10, 'spring cracker', '2.png', 'L', 100, 50.00, '2024-09-27 19:24:44'),
(11, 'spinner', '2.jpg', 'M', 30, 150.00, '2024-09-27 19:26:54'),
(12, 'Twinkle star', '1.jpg', 'S', 50, 60.00, '2024-09-28 10:35:38'),
(13, 'color full', '03.jpg', 'M', 10, 100.00, '2024-09-28 10:39:52'),
(14, 'Gun', '02.jpg', 'M', 500, 50.00, '2024-09-28 12:27:03'),
(15, 'roll cap', '01.jpg', 'M', 100, 60.00, '2024-09-28 12:31:09'),
(16, 'plains shot', '120.jpg', 'M', 20, 225.00, '2024-09-28 16:00:00'),
(17, 'Bijili pockets', 'bijili.jpg', 'L', 100, 100.00, '2024-09-30 10:08:15'),
(18, 'peocock feather', 'peocock.jpg', 'L', 50, 300.00, '2024-09-30 11:57:28'),
(19, 'mercury', 'mercury.jfif', 'M', 20, 180.00, '2024-09-30 18:24:38'),
(20, 'Goldenrain', 'gold-rain-mercury.jpg', 'M', 50, 1300.00, '2024-10-01 11:00:59'),
(21, 'seven-shot', '7shot.png', 'L', 25, 300.00, '2024-10-01 19:13:59'),
(22, '1000-gems', '1000gems-1.jpg', 'L', 30, 1200.00, '2024-10-02 16:44:45'),
(23, 'Eight shot cracker', 'eightshot.jpg', 'M', 150, 150.00, '2024-10-03 17:45:03'),
(24, 'star crackers', '12star.jpg', 'L', 250, 230.00, '2024-10-05 13:25:11'),
(25, 'coffee powder', 'login (1).png', 'sd', 2, 2.00, '2025-08-20 16:35:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Indexes for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `invoice_items`
--
ALTER TABLE `invoice_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD CONSTRAINT `invoice_items_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`invoice_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
